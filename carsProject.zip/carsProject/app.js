import express from "express";
import Database from "better-sqlite3";
import bcrypt from "bcrypt";
import fs from "fs";

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static("public"));

// data mappa létrehozása, ha még nem létezik
fs.mkdirSync("./data", { recursive: true });

// adatbázisok
const usersDb = new Database("./data/users.db");
const carsDb = new Database("./data/cars.db");

// táblák készítése, ha még nincsenek
usersDb
  .prepare(
    `
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )
`,
  )
  .run();

carsDb
  .prepare(
    `
    CREATE TABLE IF NOT EXISTS cars (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        brand TEXT NOT NULL,
        category TEXT NOT NULL,
        specs TEXT NOT NULL,
        summary TEXT NOT NULL,
        image TEXT DEFAULT '',
        isPublic INTEGER NOT NULL DEFAULT 0,
        userId INTEGER NOT NULL DEFAULT 0
    )
`,
  )
  .run();

// alap felhasználó betöltése, ha a users tábla üres (jelszó: "autok123")
const { userCount } = usersDb
  .prepare("SELECT COUNT(*) AS userCount FROM users")
  .get();
if (userCount === 0) {
  const demoHash = bcrypt.hashSync("autok123", 10);
  usersDb
    .prepare(
      `
        INSERT INTO users (username, email, password)
        VALUES (?, ?, ?)
    `,
    )
    .run("Teszt Sofőr", "sofor@autosblog.hu", demoHash);
}

// 9 alap autós blogkártya betöltése ha a tábla üres
const famousCars = [
  {
    title: "Porsche 911 GT3 (992)",
    brand: "Porsche",
    category: "Sportkupé",
    specs: "4.0L szívó boxermotor • 510 LE • Hátsókerék-hajtás",
    summary:
      "Versenypályára hangolt szívómotoros ikon, amely a mindennapi közlekedésben is precíz.",
    image: "https://images.pistonheads.com/nimg/47438/blobid0.jpg",
  },
  {
    title: "BMW M4 Competition (G80)",
    brand: "BMW",
    category: "Sportkupé",
    specs: "3.0L biturbó sorhat • 510 LE • M xDrive",
    summary:
      "Kegyetlen gyorsulás és praktikus négyajtós karosszéria egyetlen csomagban.",
    image: "https://img.hasznaltautocdn.com/640x480/23303837/28658092.jpg",
  },
  {
    title: "Audi RS6 Avant",
    brand: "Audi",
    category: "Sportkombi",
    specs: "4.0L V8 biturbó mild-hybrid • 600 LE • quattro",
    summary:
      "A családi kombi és a szupersportautó találkozása hosszú távú autópályás tempóra.",
    image:
      "https://hips.hearstapps.com/hmg-prod/images/2023-audi-rs-6-avant-performance107-6499d1e3764fc.jpg?crop=0.909xw:0.302xh;0.0705xw,0.362xh&resize=1200:*",
  },
  {
    title: "Toyota GR Yaris",
    brand: "Toyota",
    category: "Hot Hatch",
    specs: "1.6L 3-hengeres turbó • 280 LE • GR-FOUR összkerék",
    summary:
      "A rali-vb homologizációs alapjaiból épített, könnyű és agilis zsebrakéta.",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfYB4vGN6WmQeJ4cB0HCXPjEmJ2fEfBi2qINp8nnsN0uxgcPonnGN_4oYb&s=10",
  },
  {
    title: "Mazda MX-5 Roadster (ND)",
    brand: "Mazda",
    category: "Roadster",
    specs: "2.0L Skyactiv-G • 184 LE • 6 fokozatú kézi váltó",
    summary:
      "Pehelykönnyű nyitott kétüléses, ahol az élmény és a visszajelzés fontosabb a puszta lóerőknél.",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAM2zZyD0JYPpfoEWhDhULhz_Q9u8vWXav977WLgxEkuI1GlqNUtmfq884&s=10",
  },
  {
    title: "Mercedes-AMG GT 63",
    brand: "Mercedes-AMG",
    category: "Gran Turismo",
    specs: "4.0L V8 biturbó • 585 LE • AMG Performance 4MATIC+",
    summary:
      "Affalterbachi V8-as hangzás, luxus utastér és komoly kanyarsebesség.",
    image:
      "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80",
  },
  {
    title: "Volkswagen Golf GTI Clubsport",
    brand: "Volkswagen",
    category: "Hot Hatch",
    specs: "2.0L TSI turbó • 300 LE • Elsőkerék-hajtás + sperrdifi",
    summary:
      "A hot hatch kategória egyik legélesebb, mégis mindennap használható képviselője.",
    image:
      "https://www.volkswagen.hu/dam/images/79db51c4676237da3b49a68e0941b2b34952c652/84ab6787b888dc13bbe75e57aa585bcb/cf4762b5-7270-4be5-b98f-1f2170fe393c/crop:SMART/resize:3840:2560/golfgtics.jpg",
  },
  {
    title: "Ford Mustang GT",
    brand: "Ford",
    category: "Izomautó",
    specs: "5.0L Coyote V8 szívó • 450+ LE • Hátsókerék-hajtás",
    summary:
      "Klasszikus amerikai V8-as karakter modern futóművel és független hátsó felfüggesztéssel.",
    image: "https://tesztelok.hu/wp-content/uploads/ford-mustang-g-t-1.png",
  },
];

const { count } = carsDb.prepare("SELECT COUNT(*) AS count FROM cars").get();

if (count === 0) {
  const insertFamous = carsDb.prepare(`
        INSERT INTO cars (title, brand, category, specs, summary, image, isPublic, userId)
        VALUES (?, ?, ?, ?, ?, ?, 1, 0)
    `);

  famousCars.forEach((car) => {
    insertFamous.run(
      car.title,
      car.brand,
      car.category,
      car.specs,
      car.summary,
      car.image,
    );
  });
} else {
  // Meglévő publikus alap kártyák kép-URL-jeinek frissítése
  const updateFamous = carsDb.prepare(`
        UPDATE cars
        SET image = ?
        WHERE title = ? AND isPublic = 1 AND userId = 0
    `);

  famousCars.forEach((car) => {
    updateFamous.run(car.image, car.title);
  });
}

// regisztráció
app.post("/api/register", (req, res) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({ message: "Minden mező kitöltése kötelező!" });
  }

  const existing = usersDb
    .prepare("SELECT id FROM users WHERE email = ?")
    .get(email);
  if (existing) {
    return res.status(400).json({ message: "Ez az e-mail cím már foglalt!" });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  const saved = usersDb
    .prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)")
    .run(username, email, hashedPassword);

  const user = usersDb
    .prepare("SELECT id, username, email FROM users WHERE id = ?")
    .get(saved.lastInsertRowid);

  res.status(201).json(user);
});

// bejelentkezés
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  const user = usersDb
    .prepare("SELECT * FROM users WHERE email = ?")
    .get(email);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ message: "Hibás e-mail cím vagy jelszó!" });
  }

  res.status(200).json({
    id: user.id,
    username: user.username,
    email: user.email,
  });
});

// publikus 9 autós blogkártya
app.get("/api/cars/public", (req, res) => {
  const list = carsDb
    .prepare(
      "SELECT * FROM cars WHERE isPublic = 1 AND userId = 0 ORDER BY id ASC",
    )
    .all();
  res.json(list);
});

// saját autós kártyák
app.get("/api/cars/user/:userId", (req, res) => {
  const userId = Number(req.params.userId);
  const list = carsDb
    .prepare("SELECT * FROM cars WHERE userId = ? ORDER BY id DESC")
    .all(userId);
  res.json(list);
});

// új autós kártya hozzáadása
app.post("/api/cars", (req, res) => {
  const { title, brand, category, specs, summary, image, userId } = req.body;

  if (!title || !brand || !category || !specs || !summary || !userId) {
    return res.status(400).json({ message: "Hiányzó adatok!" });
  }

  const saved = carsDb
    .prepare(
      `
            INSERT INTO cars (title, brand, category, specs, summary, image, isPublic, userId)
            VALUES (?, ?, ?, ?, ?, ?, 0, ?)
        `,
    )
    .run(title, brand, category, specs, summary, image || "", Number(userId));

  const created = carsDb
    .prepare("SELECT * FROM cars WHERE id = ?")
    .get(saved.lastInsertRowid);

  res.status(201).json(created);
});

// saját autós kártya módosítása
app.put("/api/cars/:userId/:id", (req, res) => {
  const userId = Number(req.params.userId);
  const id = Number(req.params.id);
  const { title, brand, category, specs, summary, image } = req.body;

  if (!title || !brand || !category || !specs || !summary) {
    return res.status(400).json({ message: "Hiányzó adatok!" });
  }

  const existing = carsDb
    .prepare("SELECT * FROM cars WHERE id = ? AND userId = ?")
    .get(id, userId);

  if (!existing) {
    return res
      .status(404)
      .json({ message: "A bejegyzés nem található vagy nem a tied!" });
  }

  carsDb
    .prepare(
      `
            UPDATE cars
            SET title = ?, brand = ?, category = ?, specs = ?, summary = ?, image = ?
            WHERE id = ? AND userId = ?
        `,
    )
    .run(title, brand, category, specs, summary, image || "", id, userId);

  const updated = carsDb
    .prepare("SELECT * FROM cars WHERE id = ? AND userId = ?")
    .get(id, userId);

  res.status(200).json(updated);
});

// saját autós kártya törlése
app.delete("/api/cars/:userId/:id", (req, res) => {
  const userId = Number(req.params.userId);
  const id = Number(req.params.id);

  const existing = carsDb
    .prepare("SELECT * FROM cars WHERE id = ? AND userId = ?")
    .get(id, userId);

  if (!existing) {
    return res
      .status(404)
      .json({ message: "A bejegyzés nem található vagy nem a tied!" });
  }

  carsDb
    .prepare("DELETE FROM cars WHERE id = ? AND userId = ?")
    .run(id, userId);

  res.status(200).json({ message: "Bejegyzés törölve!" });
});

app.listen(PORT, () => {
  console.log(`Szerver fut: http://localhost:${PORT}`);
});
