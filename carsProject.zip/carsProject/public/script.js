let currentUser = null;

const authSection = document.getElementById("authSection");
const userSection = document.getElementById("userSection");
const userCars = document.getElementById("userCars");
const publicCars = document.getElementById("publicCars");
const message = document.getElementById("message");

function showMessage(text, isError = false) {
  message.textContent = text;
  message.style.color = isError ? "#ff6b6b" : "#51cf66";
}

// kártya létrehozása
function createCarCard(car, editable = false) {
  const col = document.createElement("div");
  col.className = "col-12 col-sm-6 col-lg-4";

  const card = document.createElement("div");
  card.className = "car-card";

  if (car.image) {
    const img = document.createElement("img");
    img.src = car.image;
    img.alt = car.title;
    img.onerror = () => {
      img.style.display = "none";
    };
    card.appendChild(img);
  }

  const badge = document.createElement("span");
  badge.className = "car-badge";
  badge.textContent = car.category;
  card.appendChild(badge);

  const title = document.createElement("h4");
  title.textContent = car.title;
  card.appendChild(title);

  const brand = document.createElement("p");
  brand.className = "car-meta";
  brand.textContent = `Márka: ${car.brand}`;
  card.appendChild(brand);

  const specs = document.createElement("p");
  specs.className = "car-specs";
  specs.textContent = car.specs;
  card.appendChild(specs);

  const summary = document.createElement("p");
  summary.className = "car-summary";
  summary.textContent = car.summary;
  card.appendChild(summary);

  if (editable && currentUser) {
    const actions = document.createElement("div");
    actions.className = "card-actions mt-2";

    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "btn btn-sm btn-warning";
    editBtn.textContent = "Szerkesztés";

    editBtn.onclick = () => {
      card.innerHTML = "";

      const titleInput = document.createElement("input");
      titleInput.className = "form-control form-control-sm mb-2";
      titleInput.value = car.title;
      titleInput.placeholder = "Modell neve";

      const brandInput = document.createElement("input");
      brandInput.className = "form-control form-control-sm mb-2";
      brandInput.value = car.brand;
      brandInput.placeholder = "Márka";

      const catInput = document.createElement("input");
      catInput.className = "form-control form-control-sm mb-2";
      catInput.value = car.category;
      catInput.placeholder = "Kategória";

      const specsInput = document.createElement("input");
      specsInput.className = "form-control form-control-sm mb-2";
      specsInput.value = car.specs;
      specsInput.placeholder = "Műszaki adatok";

      const summaryInput = document.createElement("textarea");
      summaryInput.className = "form-control form-control-sm mb-2";
      summaryInput.rows = 3;
      summaryInput.value = car.summary;
      summaryInput.placeholder = "Rövid blogösszefoglaló / vélemény";

      const imgInput = document.createElement("input");
      imgInput.className = "form-control form-control-sm mb-2";
      imgInput.value = car.image || "";
      imgInput.placeholder = "Kép URL-je";

      card.append(
        titleInput,
        brandInput,
        catInput,
        specsInput,
        summaryInput,
        imgInput,
      );

      const saveBtn = document.createElement("button");
      saveBtn.type = "button";
      saveBtn.className = "btn btn-sm btn-success me-2";
      saveBtn.textContent = "Mentés";

      saveBtn.onclick = () => {
        fetch(`/api/cars/${currentUser.id}/${car.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: titleInput.value.trim(),
            brand: brandInput.value.trim(),
            category: catInput.value.trim(),
            specs: specsInput.value.trim(),
            summary: summaryInput.value.trim(),
            image: imgInput.value.trim(),
          }),
        })
          .then((res) => res.json())
          .then((data) => {
            if (data.id) {
              showMessage("Kártya frissítve!");
              loadUserCars();
            } else {
              showMessage(data.message || "Nem sikerült a módosítás!", true);
            }
          })
          .catch(() => showMessage("Hiba történt a módosítás során!", true));
      };

      const cancelBtn = document.createElement("button");
      cancelBtn.type = "button";
      cancelBtn.className = "btn btn-sm btn-secondary";
      cancelBtn.textContent = "Mégse";
      cancelBtn.onclick = loadUserCars;

      card.append(saveBtn, cancelBtn);
    };

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "btn btn-sm btn-danger ms-2";
    deleteBtn.textContent = "Törlés";

    deleteBtn.onclick = () => {
      if (!confirm("Biztosan törlöd ezt az autós kártyát?")) return;

      fetch(`/api/cars/${currentUser.id}/${car.id}`, {
        method: "DELETE",
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.message) {
            showMessage("Kártya törölve!");
            loadUserCars();
          } else {
            showMessage("Nem sikerült a törlés!", true);
          }
        })
        .catch(() => showMessage("Hiba történt a törlés során!", true));
    };

    actions.append(editBtn, deleteBtn);
    card.appendChild(actions);
  }

  col.appendChild(card);
  return col;
}

// 9 autó
function loadPublicCars() {
  fetch("/api/cars/public")
    .then((res) => res.json())
    .then((data) => {
      publicCars.innerHTML = "";
      data.forEach((car) => {
        publicCars.appendChild(createCarCard(car, false));
      });
    })
    .catch(() =>
      showMessage("Nem sikerült betölteni a kiemelt autókat!", true),
    );
}

// saját kártyák
function loadUserCars() {
  if (!currentUser) return;

  fetch(`/api/cars/user/${currentUser.id}`)
    .then((res) => res.json())
    .then((data) => {
      userCars.innerHTML = "";
      if (data.length === 0) {
        userCars.innerHTML =
          "<p class='text-secondary'>Még nincs saját autós kártyád.</p>";
        return;
      }
      data.forEach((car) => {
        userCars.appendChild(createCarCard(car, true));
      });
    })
    .catch(() =>
      showMessage("Nem sikerült betölteni a saját kártyákat!", true),
    );
}

// regisztráció
document.getElementById("registerForm").onsubmit = (e) => {
  e.preventDefault();

  fetch("/api/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: document.getElementById("regUsername").value.trim(),
      email: document.getElementById("regEmail").value.trim(),
      password: document.getElementById("regPassword").value,
    }),
  })
    .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
    .then(({ ok, data }) => {
      if (ok) {
        showMessage("Sikeres regisztráció! Most már bejelentkezhetsz.");
        e.target.reset();
      } else {
        showMessage(data.message || "Sikertelen regisztráció!", true);
      }
    })
    .catch(() => showMessage("Hiba történt a regisztráció során!", true));
};

// bejelentkezés
document.getElementById("loginForm").onsubmit = (e) => {
  e.preventDefault();

  fetch("/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: document.getElementById("loginEmail").value.trim(),
      password: document.getElementById("loginPassword").value,
    }),
  })
    .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
    .then(({ ok, data }) => {
      if (ok && data.id) {
        currentUser = data;
        authSection.hidden = true;
        userSection.hidden = false;
        document.getElementById("welcome").textContent =
          `Szia, ${data.username}!`;
        e.target.reset();
        showMessage("");
        loadUserCars();
      } else {
        showMessage(data.message || "Hibás e-mail cím vagy jelszó!", true);
      }
    })
    .catch(() => showMessage("Hiba történt a bejelentkezés során!", true));
};

// új autós kártya mentése
document.getElementById("carForm").onsubmit = (e) => {
  e.preventDefault();
  if (!currentUser) return;

  fetch("/api/cars", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      title: document.getElementById("carTitle").value.trim(),
      brand: document.getElementById("carBrand").value.trim(),
      category: document.getElementById("carCategory").value.trim(),
      specs: document.getElementById("carSpecs").value.trim(),
      summary: document.getElementById("carSummary").value.trim(),
      image: document.getElementById("carImage").value.trim(),
      userId: currentUser.id,
    }),
  })
    .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
    .then(({ ok, data }) => {
      if (ok && data.id) {
        e.target.reset();
        showMessage("Új autós kártya elmentve!");
        loadUserCars();
      } else {
        showMessage(data.message || "Nem sikerült a mentés!", true);
      }
    })
    .catch(() => showMessage("Hiba történt a mentés során!", true));
};

// kijelentkezés
document.getElementById("logoutButton").onclick = () => {
  currentUser = null;
  userCars.innerHTML = "";
  userSection.hidden = true;
  authSection.hidden = false;
  showMessage("");
  document.querySelectorAll("form").forEach((form) => form.reset());
};

loadPublicCars();
